import os
import json
import datetime
import subprocess
import tempfile
import shutil
import atexit
import logging
from pathlib import Path
from typing import List, Tuple, Optional, Dict, Any

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('video_creation.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class VideoConfig:
    """Configuration class for video creation parameters"""
    def __init__(
        self,
        video_size: str = "1080x1920",
        fps: int = 30,
        video_codec: str = "libx264",
        audio_codec: str = "aac",
        default_segment_duration: float = 5.0,
        video_format: str = "yuv420p"
    ):
        self.video_size = video_size
        self.fps = fps
        self.video_codec = video_codec
        self.audio_codec = audio_codec
        self.default_segment_duration = default_segment_duration
        self.video_format = video_format

class VideoCreationError(Exception):
    """Custom exception for video creation errors"""
    pass

def get_audio_duration(audio_path: str) -> Optional[float]:
    """Get the duration of an audio file in seconds"""
    try:
        cmd = [
            "ffprobe", "-v", "quiet", "-show_entries", "format=duration",
            "-of", "csv=p=0", audio_path
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        return float(result.stdout.strip())
    except (subprocess.CalledProcessError, ValueError) as e:
        logger.warning(f"Could not get audio duration: {e}")
        return None

def timestamp_to_seconds(timestamp_str: str) -> float:
    """
    Convert timestamp string to seconds.
    Supports formats: MM:SS, HH:MM:SS, SS.mmm
    """
    try:
        # Handle decimal seconds
        if '.' in timestamp_str and ':' not in timestamp_str:
            return float(timestamp_str)
        
        parts = timestamp_str.split(':')
        if len(parts) == 2:  # MM:SS
            minutes, seconds = parts
            return int(minutes) * 60 + float(seconds)
        elif len(parts) == 3:  # HH:MM:SS
            hours, minutes, seconds = parts
            return int(hours) * 3600 + int(minutes) * 60 + float(seconds)
        else:
            raise ValueError(f"Invalid timestamp format: {timestamp_str}")
    except (ValueError, IndexError) as e:
        raise VideoCreationError(f"Failed to parse timestamp '{timestamp_str}': {e}")

def validate_inputs(image_folder: str, timestamp_json_path: str, audio_path: str) -> None:
    """Validate all input files and folders exist"""
    image_folder_path = Path(image_folder)
    timestamp_json_path_obj = Path(timestamp_json_path)
    audio_path_obj = Path(audio_path)
    
    if not image_folder_path.exists():
        raise VideoCreationError(f"Image folder not found: {image_folder}")
    
    if not image_folder_path.is_dir():
        raise VideoCreationError(f"Image folder path is not a directory: {image_folder}")
    
    if not timestamp_json_path_obj.exists():
        raise VideoCreationError(f"Timestamp JSON file not found: {timestamp_json_path}")
    
    if not audio_path_obj.exists():
        raise VideoCreationError(f"Audio file not found: {audio_path}")

def validate_json_structure(data: List[Dict[str, Any]]) -> None:
    """Validate the structure of the timestamp JSON data"""
    required_fields = {"timestamp", "image_name"}
    
    if not isinstance(data, list):
        raise VideoCreationError("JSON data must be a list")
    
    if not data:
        raise VideoCreationError("JSON data cannot be empty")
    
    for i, item in enumerate(data):
        if not isinstance(item, dict):
            raise VideoCreationError(f"Item {i} must be a dictionary")
        
        missing_fields = required_fields - set(item.keys())
        if missing_fields:
            raise VideoCreationError(f"Item {i} missing required fields: {missing_fields}")

def run_ffmpeg_command(cmd: List[str], description: str) -> bool:
    """Run FFmpeg command with proper error handling"""
    try:
        logger.info(f"Running: {description}")
        result = subprocess.run(
            cmd, 
            capture_output=True, 
            text=True, 
            check=True
        )
        logger.debug(f"FFmpeg stdout: {result.stdout}")
        return True
    except subprocess.CalledProcessError as e:
        logger.error(f"FFmpeg error during {description}:")
        logger.error(f"Command: {' '.join(cmd)}")
        logger.error(f"Return code: {e.returncode}")
        logger.error(f"stderr: {e.stderr}")
        return False
    except Exception as e:
        logger.error(f"Unexpected error during {description}: {e}")
        return False

def create_image_clip(
    img_path: str, 
    duration: float, 
    output_path: str, 
    config: VideoConfig
) -> bool:
    """Create a video clip from a single image"""
    # Parse video dimensions
    width, height = config.video_size.split('x')
    
    cmd = [
        "ffmpeg", "-y",
        "-loop", "1",
        "-i", img_path,
        "-vf", f"scale={config.video_size}:force_original_aspect_ratio=decrease,"
               f"pad={width}:{height}:(ow-iw)/2:(oh-ih)/2,format={config.video_format}",
        "-t", str(duration),
        "-r", str(config.fps),
        "-c:v", config.video_codec,
        output_path
    ]
    
    return run_ffmpeg_command(cmd, f"Creating clip from {Path(img_path).name}")

def create_slide_video(
    image_folder: str, 
    timestamp_json_path: str, 
    audio_path: str, 
    output_path: str = "final_video.mp4",
    config: Optional[VideoConfig] = None
) -> bool:
    """
    Create a slide video from images, timestamps, and audio.
    
    Args:
        image_folder: Path to folder containing images
        timestamp_json_path: Path to JSON file with timestamps
        audio_path: Path to audio file
        output_path: Output video file path
        config: Video configuration parameters
    
    Returns:
        bool: True if successful, False otherwise
    """
    if config is None:
        config = VideoConfig()
    
    # Create temporary directory for processing
    temp_dir = tempfile.mkdtemp(prefix="video_creation_")
    logger.info(f"Using temporary directory: {temp_dir}")
    
    # Register cleanup function
    def cleanup():
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir, ignore_errors=True)
            logger.info("Temporary files cleaned up")
    
    atexit.register(cleanup)
    
    try:
        # Validate inputs
        logger.info("Validating inputs...")
        validate_inputs(image_folder, timestamp_json_path, audio_path)
        
        # Load and validate JSON data
        logger.info("Loading timestamp data...")
        with open(timestamp_json_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        
        validate_json_structure(data)
        
        # Sort data by timestamp
        data.sort(key=lambda x: timestamp_to_seconds(x["timestamp"]))
        logger.info(f"Loaded {len(data)} timestamp entries")
        
        # Get audio duration for better last segment handling
        audio_duration = get_audio_duration(audio_path)
        if audio_duration:
            logger.info(f"Audio duration: {audio_duration:.2f} seconds")
        
        # Process timestamp data into segments
        image_segments = []
        for i, item in enumerate(data):
            start = timestamp_to_seconds(item["timestamp"])
            
            # Calculate duration
            if i + 1 < len(data):
                end = timestamp_to_seconds(data[i + 1]["timestamp"])
                duration = end - start
            else:
                # Last segment: use remaining audio time or default
                if audio_duration:
                    duration = max(audio_duration - start, config.default_segment_duration)
                else:
                    duration = config.default_segment_duration
            
            image_file = Path(image_folder) / item["image_name"]
            image_segments.append((str(image_file), start, duration))
        
        logger.info(f"Created {len(image_segments)} image segments")
        
        # Create individual clips
        temp_clips = []
        missing_images = []
        
        for idx, (img_path, start, duration) in enumerate(image_segments):
            if not Path(img_path).exists():
                logger.warning(f"Missing image: {img_path}")
                missing_images.append(img_path)
                continue
            
            clip_path = str(Path(temp_dir) / f"temp_clip_{idx:03d}.mp4")
            
            if create_image_clip(img_path, duration, clip_path, config):
                temp_clips.append(clip_path)
                logger.info(f"Created clip {idx + 1}/{len(image_segments)}")
            else:
                logger.error(f"Failed to create clip from {img_path}")
                return False
        
        if missing_images:
            logger.warning(f"Skipped {len(missing_images)} missing images")
        
        if not temp_clips:
            raise VideoCreationError("No valid clips were created")
        
        # Create concat file
        inputs_file = Path(temp_dir) / "inputs.txt"
        with open(inputs_file, "w") as f:
            for clip in temp_clips:
                # Use forward slashes for FFmpeg compatibility
                clip_path = clip.replace("\\", "/")
                f.write(f"file '{clip_path}'\n")
        
        # Merge video clips
        merged_path = str(Path(temp_dir) / "merged_video.mp4")
        merge_cmd = [
            "ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(inputs_file),
            "-c", "copy", merged_path
        ]
        
        if not run_ffmpeg_command(merge_cmd, "Merging video clips"):
            return False
        
        # Combine with audio
        final_cmd = [
            "ffmpeg", "-y",
            "-i", merged_path,
            "-i", audio_path,
            "-c:v", "copy",
            "-c:a", config.audio_codec,
            "-shortest",
            output_path
        ]
        
        if not run_ffmpeg_command(final_cmd, "Adding audio to video"):
            return False
        
        logger.info(f"✅ Final video saved at: {output_path}")
        
        # Manual cleanup before exit
        cleanup()
        atexit.unregister(cleanup)
        
        return True
        
    except VideoCreationError as e:
        logger.error(f"Video creation error: {e}")
        return False
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        return False

def main():
    """Example usage of the video creation function"""
    # Example configuration
    config = VideoConfig(
        video_size="1080x1920",
        fps=30,
        default_segment_duration=3.0
    )
    
    # Example usage
    success = create_slide_video(
        image_folder="images",
        timestamp_json_path="timestamps.json",
        audio_path="output/output.mp3",
        output_path="final_video.mp4",
        config=config
    )
    
    if success:
        print("Video created successfully!")
    else:
        print("Video creation failed. Check the logs for details.")

if __name__ == "__main__":
    main()
