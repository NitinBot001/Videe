import requests
import os
from typing import List, Tuple

def generate_audio_with_failover(
    script: str,
    voice_id: str,
    api_keys: List[str],
    output_path: str = "output/output.mp3"
) -> Tuple[str, str]:
    """
    Generate audio using ElevenLabs TTS with fallback across multiple API keys.

    Args:
        script (str): Text to convert into speech.
        voice_id (str): Voice ID for ElevenLabs.
        api_keys (List[str]): List of ElevenLabs API keys to try.
        output_path (str): File path to save the generated MP3.

    Returns:
        Tuple[str, str]: ("success" or "error", message)
    """
    url = f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}"
    data = {
        "text": script,
        "model_id": "eleven_multilingual_v2",
        "voice_settings": {
            "stability": 0.5,
            "similarity_boost": 0.5
        }
    }

    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    for idx, api_key in enumerate(api_keys):
        headers = {
            "xi-api-key": api_key,
            "Content-Type": "application/json"
        }

        try:
            response = requests.post(url, json=data, headers=headers)

            if response.status_code == 200:
                with open(output_path, "wb") as f:
                    f.write(response.content)
                print(f"✅ Audio saved as {output_path} using API key #{idx + 1}")
                return "success", f"Audio generated using API key #{idx + 1}"
            else:
                print(f"❌ API key #{idx + 1} failed: {response.status_code} - {response.text}")
        except Exception as e:
            print(f"⚠️ Exception with API key #{idx + 1}: {e}")

    return "error", "All API keys failed. Audio not generated."

# Optional direct test
if __name__ == "__main__":
    script = "क्या आप जानते हैं, एक बीज में पूरा पेड़ बनने की क्षमता होती है?"
    voice_id = "EXAVITQu4vr4xnSDxMaL"
    api_keys = [
        "api-key-1",
        "api-key-2",
        "api-key-3"
    ]
    status, message = generate_audio_with_failover(script, voice_id, api_keys)
    print(f"{status.upper()}: {message}")
