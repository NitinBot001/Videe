import requests

TOKEN = "YOUR_FREESOUND_API_KEY"
headers = {"Authorization": f"Token {TOKEN}"}

params = {
    "query": "piano",
    "filter": "duration:[10 TO 120]",
    "fields": "id,name,previews,duration,tags",
    "page_size": 5
}

response = requests.get("https://freesound.org/apiv2/search/text/", headers=headers, params=params)

if response.status_code == 200:
    results = response.json()["results"]
    for sound in results:
        print(f"{sound['name']} - {sound['duration']}s")
        print("Preview URL:", sound['previews']['preview-hq-mp3'])
        print()
else:
    print("Error:", response.status_code, response.text)
