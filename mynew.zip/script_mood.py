import os
from google import genai
from google.genai import types

def generate_script(title, description):
    try:
        # Get API key from environment
        api_key = os.environ.get("GEMINI_API_KEY","AIzaSyBQBfbhPqtL2SEKh3l_0cE6zIxwMKLTi-A")
        if not api_key:
            return {
                "status": 500,
                "error": "GEMINI_API_KEY environment variable not set"
            }
            
        client = genai.Client(api_key=api_key)
        
        # Prompt to analyze mood from title and description
        mood_prompt = f"""Analyze the following title and description to determine the primary emotional mood. Return only the mood as a single word (e.g., happy, sad, angry, motivational, inspirational, serious, etc.).

Title: {title}
Description: {description}"""
        
        mood_contents = [
            types.Content(
                role="user",
                parts=[
                    types.Part.from_text(text=mood_prompt),
                ],
            ),
        ]
        mood_config = types.GenerateContentConfig(
            response_mime_type="text/plain"
        )
        
        mood_response = client.models.generate_content(
            model="gemini-2.0-flash",
            contents=mood_contents,
            config=mood_config
        )
        mood = mood_response.text.strip().lower()

        # System instruction for script generation
        system_instruction = f"""You are a professional Hindi voiceover scriptwriter. Your task is to write clear, emotional, and educational Hindi scripts for 60-second videos, with a maximum of 150 words.

Follow these rules:
1. Use only **easy-to-understand Hindi** (no English words).
2. The script must be a **spoken narration** — like someone is explaining emotionally to the audience.
3. Absolutely avoid:
   - Any visual descriptions (e.g., किसान खेत में पानी दे रहा है)
   - Brackets (), [], or quotes
   - Scene suggestions or editing cues
4. The script must include:
   - A curious/emotional **hook** to grab attention
   - Core **topic explanation with 2–3 relatable examples**
   - A strong, **motivating closing line**
5. Response must be a **single paragraph**, clean Hindi only — like a narrator talking straight.
6. Word count must not exceed **150 words**.
7. The tone should align with the mood: {mood}."""
        
        user_prompt = f"""Topic: {title}
Description: {description}

Generate a 60-second Hindi voiceover script (max 150 words) following all system rules."""

        contents = [
            types.Content(
                role="user",
                parts=[
                    types.Part.from_text(text=user_prompt),
                ],
            ),
        ]
        config = types.GenerateContentConfig(
            system_instruction=[
                types.Part.from_text(text=system_instruction),
            ],
            response_mime_type="text/plain"
        )

        response = client.models.generate_content(
            model="gemini-2.0-flash",
            contents=contents,
            config=config
        )

        script = response.text.strip()
        # Basic word count check
        word_count = len(script.split())
        if word_count > 150:
            return {
                "status": 400,
                "error": f"Script exceeds 150-word limit: {word_count} words"
            }

        return {
            "status": 200,
            "script": script,
            "mood": mood,
            "word_count": word_count
        }

    except Exception as e:
        return {
            "status": 500,
            "error": f"Failed to generate script: {str(e)}"
        }

# Example usage
if __name__ == "__main__":
    # Test the function
    result = generate_script(
        title="सफलता का राज",
        description="जीवन में सफल होने के लिए क्या करना चाहिए"
    )
    print(result)
