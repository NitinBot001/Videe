# together_image_generator.py

import requests
import os
import time
import json

class TogetherImageGenerator:
    def __init__(self, api_key, output_dir="images", model="black-forest-labs/FLUX.1-schnell-Free", delay=5):
        self.api_key = api_key
        self.output_dir = output_dir
        self.model = model
        self.delay = delay
        os.makedirs(output_dir, exist_ok=True)

    def generate_image(self, prompt_text, image_number):
        payload = {
            "model": self.model,
            "prompt": prompt_text,
            "n" : 4,
            "width" : 432,
            "height" : 768
        }

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }

        print(f"📸 Generating image {image_number}...")

        try:
            response = requests.post("https://api.together.xyz/v1/images/generations", headers=headers, json=payload)
            
            # Debug: Print the full response
            print(f"🔍 Response status: {response.status_code}")
            print(f"🔍 Response content: {response.text}")
            
            if response.status_code == 200:
                result = response.json()
                print(f"🔍 Parsed JSON: {json.dumps(result, indent=2)}")
                
                # Handle different possible response structures
                image_url = None
                
                # Try different possible response structures
                if "data" in result and isinstance(result["data"], list) and len(result["data"]) > 0:
                    # OpenAI-style response
                    image_url = result["data"][0].get("url")
                elif "output" in result:
                    if isinstance(result["output"], list) and len(result["output"]) > 0:
                        # List of outputs
                        image_url = result["output"][0].get("url")
                    elif isinstance(result["output"], dict):
                        # Single output object
                        image_url = result["output"].get("url")
                elif "url" in result:
                    # Direct URL in response
                    image_url = result["url"]
                elif "image_url" in result:
                    # Alternative field name
                    image_url = result["image_url"]
                
                if image_url:
                    print(f"🔗 Image URL: {image_url}")
                    try:
                        image_data = requests.get(image_url).content
                        image_path = os.path.join(self.output_dir, f"image_{image_number}.png")
                        with open(image_path, "wb") as f:
                            f.write(image_data)
                        print(f"✅ SUCCESS: Saved image {image_number} to {image_path}")
                        return image_path
                    except Exception as e:
                        print(f"❌ FAILED: Could not download/save image {image_number}: {e}")
                        return None
                else:
                    print(f"❌ FAILED: No image URL found in response for image {image_number}")
                    print(f"🔍 Available keys: {list(result.keys()) if isinstance(result, dict) else 'Response is not a dict'}")
                    print("💡 The API response structure may have changed")
                    return None
                
        except requests.exceptions.RequestException as e:
            print(f"🚫 Network error generating image {image_number}: {e}")
        except json.JSONDecodeError as e:
            print(f"🚫 JSON decode error for image {image_number}: {e}")
            print(f"🔍 Raw response: {response.text}")
        except Exception as e:
            print(f"🚫 Unexpected error generating image {image_number}: {e}")
            print(f"🔍 Error type: {type(e).__name__}")
            
        return None

    def generate_images_from_prompts(self, prompts):
        # Input validation and parsing
        if isinstance(prompts, str):
            print("🔧 Input is a string, attempting to parse as JSON...")
            try:
                prompts = json.loads(prompts)
                print("✅ Successfully parsed JSON string")
            except json.JSONDecodeError as e:
                print(f"❌ FAILED: Could not parse JSON string - {e}")
                print("💡 Please ensure your input is a valid JSON array or Python list")
                return {"status": "error", "message": "Invalid JSON format", "successful_generations": 0}
        
        if not isinstance(prompts, list):
            print(f"❌ FAILED: Input must be a list, received {type(prompts).__name__}")
            print("💡 Expected format: [{'id': 1, 'prompt': '...', 'description': '...'}, ...]")
            return {"status": "error", "message": f"Invalid input type: {type(prompts).__name__}", "successful_generations": 0}
        
        if len(prompts) == 0:
            print("❌ FAILED: No prompts provided in the list")
            print("💡 Please provide at least one prompt to generate images")
            return {"status": "error", "message": "Empty prompts list", "successful_generations": 0}
        
        print(f"📊 Found {len(prompts)} prompts to process")
        
        successful_generations = 0
        total_prompts = len(prompts)
        
        for i, item in enumerate(prompts, 1):
            print(f"\n🎯 Processing prompt {i}/{total_prompts}")
            
            # Debug: show what we're working with
            print(f"🔍 Item type: {type(item)}")
            if isinstance(item, dict):
                print(f"🔍 Item keys: {list(item.keys())}")
                print(f"📝 Description: {item.get('description', 'No description')}")
                
                # Use 'id' field from your input format
                image_id = item.get("id", i)  # Fallback to index if no id
                prompt_text = item.get("prompt", "")
                
                if not prompt_text:
                    print(f"❌ SKIPPED: No prompt text found for item {i}")
                    print("💡 Each item must have a 'prompt' field with text")
                    continue
                    
                result = self.generate_image(prompt_text, image_id)
                
                if result:
                    successful_generations += 1
            else:
                print(f"❌ SKIPPED: Item {i} is not a dictionary")
                print(f"💡 Expected dictionary, got: {type(item).__name__}")
                print(f"🔍 Item content: {str(item)[:100]}...")
                continue
            
            # Don't wait after the last image
            if i < total_prompts:
                print(f"⏳ Waiting {self.delay} seconds before next image...")
                time.sleep(self.delay)
        
        print(f"\n📊 FINAL RESULT: {successful_generations}/{total_prompts} images generated successfully")
        
        if successful_generations == 0:
            print("❌ GENERATION FAILED: No images were successfully created")
            print("💡 Check your API key, network connection, and prompt format")
            return {"status": "failed", "message": "No images generated", "successful_generations": 0, "total_prompts": total_prompts}
        elif successful_generations == total_prompts:
            print("✅ GENERATION COMPLETE: All images created successfully!")
            return {"status": "success", "message": "All images generated", "successful_generations": successful_generations, "total_prompts": total_prompts}
        else:
            print(f"⚠️ PARTIAL SUCCESS: {successful_generations} out of {total_prompts} images generated")
            print("💡 Some images failed - check the error messages above")
            return {"status": "partial", "message": f"Partial success: {successful_generations}/{total_prompts}", "successful_generations": successful_generations, "total_prompts": total_prompts}

# Example usage:
if __name__ == "__main__":
    # Test with your API key
    api_key = "your_api_key_here"  # Replace with your actual API key
    
    # Your actual input format
    images_prompt = [
        {
            "id": 1,
            "description": "A lush green planet Earth with water droplets surrounding it, symbolizing its dependence on water.",
            "prompt": "A vibrant, photorealistic image of planet Earth surrounded by glistening water droplets, emphasizing the importance of water"
        },
        {
            "id": 2,
            "description": "A parched agricultural field with cracked soil, representing the problem of water scarcity in farming.",
            "prompt": "A desolate agricultural field with dry, cracked earth under a scorching sun, visually depicting the severe impact of water scarcity"
        }
    ]
    
    together_generator = TogetherImageGenerator(api_key=api_key, delay=5)
    together_generator.generate_images_from_prompts(images_prompt)
    print("Image generation completed.")
