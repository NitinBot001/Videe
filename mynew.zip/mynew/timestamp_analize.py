import json
from typing import List, Dict
from google import genai
from google.genai import types
import os

API_KEY = os.getenv("GEMINI_API_KEY", "AIzaSyAK6RM5qCAnsyIbVRSoIn3hIekZDw8SXSA")
client = genai.Client(api_key=API_KEY)

def build_prompt(script_text: str, transcript_data: List[Dict], image_metadata: List[Dict]) -> str:
    return f"""
तुम्हारा कार्य है एक वीडियो स्क्रिप्ट, उसके टाइमस्टैम्प वाले ट्रांसक्रिप्ट और इमेज मेटाडेटा को देखकर यह बताना कि कौन सी फोटो (image_number) किस समय (timestamp) पर लगाई जानी चाहिए।

यह निर्णय भावना (emotion), context (text) और meaning के आधार पर दो।

**स्क्रिप्ट:**
{script_text}

**ट्रांसक्रिप्ट:**
{json.dumps(transcript_data, ensure_ascii=False, indent=2)}

**इमेज मेटाडेटा:**
{json.dumps(image_metadata, ensure_ascii=False, indent=2)}

उत्तर केवल इस फ़ॉर्मेट में दो:
[
  {{
    "timestamp": "00:10",
    "image_number": 1,
    "image_name": "image_1.png",
    "reason": "पानी की ताकत पर बात हो रही है, इसलिए hopeful इमेज सही है"
  }},
  {{
    "timestamp": "00:25",
    "image_number": 5,
    "image_name": "image_5.png",
    "reason": "भावनात्मक मोड़ है, इसलिए इस इमेज का चुनाव हुआ"
  }}
]
"""

def get_image_placements(script_text: str, transcript_data: List[Dict], image_metadata: List[Dict]) -> List[Dict]:
    try:
        prompt = build_prompt(script_text, transcript_data, image_metadata)

        contents = [
            types.Content(
                role="user", 
                parts=[
                    types.Part.from_text(text=prompt)
                ]
            )
        ]

        config = types.GenerateContentConfig(
            response_mime_type="application/json"
        )

        response = client.models.generate_content(
            model="gemini-2.0-flash-exp",  # Updated model
            contents=contents,
            config=config
        )

        raw = response.text.strip()
        
        # Parse JSON response
        try:
            placements = json.loads(raw)
            return placements
        except json.JSONDecodeError as e:
            print(f"❌ JSON Parse Error: {e}")
            print(f"Raw response: {raw}")
            return []
            
    except Exception as e:
        print("❌ Error from Gemini:\n", e)
        return []

def test_image_placements():
    """Test function with sample data"""
    
    # Sample script
    script_text = """
स्टील की थाली के फायदे जानकर आप हैरान हो जाएंगे। पहला फायदा, स्टील में कोई हानिकारक रसायन नहीं होते। दूसरा, यह टिकाऊ होती है। तीसरा, पर्यावरण के लिए सुरक्षित है।
"""
    
    # Sample transcript data
    transcript_data = [
        {"timestamp": "00:00", "text": "स्टील की थाली के फायदे जानकर आप हैरान हो जाएंगे"},
        {"timestamp": "00:05", "text": "पहला फायदा, स्टील में कोई हानिकारक रसायन नहीं होते"},
        {"timestamp": "00:10", "text": "दूसरा, यह टिकाऊ होती है"},
        {"timestamp": "00:15", "text": "तीसरा, पर्यावरण के लिए सुरक्षित है"}
    ]
    
    # Sample image metadata
    image_metadata = [
        {"id": 1, "description": "Steel plate with healthy food", "prompt": "Shiny steel plate with colorful vegetables"},
        {"id": 2, "description": "Toxic plastic containers", "prompt": "Dangerous plastic containers with warning signs"},
        {"id": 3, "description": "Durable steel kitchenware", "prompt": "Long-lasting steel kitchen utensils"},
        {"id": 4, "description": "Green environment concept", "prompt": "Eco-friendly green environment with recycling symbols"}
    ]
    
    result = get_image_placements(script_text, transcript_data, image_metadata)
    print("Image Placements Result:")
    print(json.dumps(result, indent=2, ensure_ascii=False))
    
    return result

if __name__ == "__main__":
    test_image_placements()
