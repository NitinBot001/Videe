import whisper_timestamped

def transcribe_audio_with_timestamps(file_path: str, model_size: str = "base") -> list:
    """
    Transcribe an audio file using whisper_timestamped and return a list of segments with timestamps.

    Args:
        file_path (str): Path to the audio file (e.g., MP3, WAV).
        model_size (str): Model size to use ("tiny", "base", "small", "medium", "large").

    Returns:
        List[Dict[str, Any]]: List of segments with 'start', 'end', and 'text'.
    """
    try:
        model = whisper_timestamped.load_model(model_size)
        result = whisper_timestamped.transcribe(model, file_path)
        return [
            {
                "start": segment['start'],
                "end": segment['end'],
                "text": segment['text']
            }
            for segment in result['segments']
        ]
    except Exception as e:
        return [{"error": str(e)}]

# Optional test block
if __name__ == "__main__":
    audio_file = "output.mp3"
    segments = transcribe_audio_with_timestamps(audio_file)
    for segment in segments:
        print(segment)
