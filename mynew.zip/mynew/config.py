# config.py - Configuration management
import os
from datetime import timedelta

class Config:
    # Flask settings
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-secret-key-please-change-in-production'
    
    # File upload settings
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB
    UPLOAD_FOLDER = os.environ.get('UPLOAD_FOLDER') or 'uploads'
    
    # Job settings
    JOB_CLEANUP_HOURS = int(os.environ.get('JOB_CLEANUP_HOURS', 24))
    MAX_CONCURRENT_JOBS = int(os.environ.get('MAX_CONCURRENT_JOBS', 5))
    
    # API Keys (move these to environment variables)
    ELEVENLABS_API_KEYS = [
        os.environ.get('ELEVENLABS_API_KEY_1'),
        os.environ.get('ELEVENLABS_API_KEY_2'),
        os.environ.get('ELEVENLABS_API_KEY_3'),
    ]
    TOGETHER_AI_API_KEY = os.environ.get('TOGETHER_AI_API_KEY')
    GOOGLE_API_KEY = os.environ.get('GOOGLE_API_KEY')  # For Gemini
    
    # Default voice settings
    DEFAULT_VOICE_ID = os.environ.get('DEFAULT_VOICE_ID', 'm5qndnI7u4OAdXhH0Mr5')
    
    # Storage settings
    JOBS_DIRECTORY = os.environ.get('JOBS_DIRECTORY') or 'jobs'
    
    @staticmethod
    def init_app(app):
        # Create necessary directories
        os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)
        os.makedirs(Config.JOBS_DIRECTORY, exist_ok=True)

class DevelopmentConfig(Config):
    DEBUG = True
    
class ProductionConfig(Config):
    DEBUG = False
    
    @classmethod
    def init_app(cls, app):
        Config.init_app(app)
        
        # Log to syslog in production
        import logging
        from logging.handlers import SysLogHandler
        syslog_handler = SysLogHandler()
        syslog_handler.setLevel(logging.WARNING)
        app.logger.addHandler(syslog_handler)

config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'default': DevelopmentConfig
}

# wsgi.py - WSGI entry point for production
from app import app

if __name__ == "__main__":
    app.run()

# gunicorn_config.py - Gunicorn configuration
import multiprocessing

# Server socket
bind = "0.0.0.0:5000"
backlog = 2048

# Worker processes
workers = multiprocessing.cpu_count() * 2 + 1
worker_class = 'sync'
worker_connections = 1000
timeout = 300
keepalive = 2

# Restart workers after this many requests, to prevent memory leaks
max_requests = 1000
max_requests_jitter = 100

# Logging
accesslog = '-'
errorlog = '-'
loglevel = 'info'
access_log_format = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s" %(D)s'

# Process naming
proc_name = 'video_generator'

# Server mechanics
daemon = False
pidfile = '/tmp/gunicorn.pid'
user = None
group = None
tmp_upload_dir = None

# Preload app for better performance
preload_app = True
