from flask import Flask, request, render_template, jsonify, send_file, redirect, url_for
from werkzeug.utils import secure_filename
import os
import json
import threading
import time
from datetime import datetime, timedelta
import uuid
import logging
import traceback
import shutil

# Import your existing modules
try:
    from image_generation import TogetherImageGenerator
    from trasnscript import transcribe_audio_with_timestamps
    from script_mood import generate_script
    from voiceover import generate_audio_with_failover
    from video_generation import create_slide_video
    from timestamp_analize import get_image_placements
    from image_prompt import extract_image_prompts_from_script as generate_image_prompts
except ImportError as e:
    logging.error(f"Module import error: {str(e)}")
    # Create dummy functions to prevent crashes
    def generate_script(*args, **kwargs): 
        return {"error": "Module import failed", "status": 500}
    def generate_audio_with_failover(*args, **kwargs): 
        return "error", "Module import failed"
    def transcribe_audio_with_timestamps(*args, **kwargs): 
        return [{"error": "Module import failed"}]
    def generate_image_prompts(*args, **kwargs): 
        return {"error": "Module import failed"}
    def TogetherImageGenerator(*args, **kwargs):
        class DummyGenerator:
            def generate_images_from_prompts(*args, **kwargs): 
                pass
        return DummyGenerator()
    def get_image_placements(*args, **kwargs): 
        return []
    def create_slide_video(*args, **kwargs): 
        pass

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.FileHandler("video_generation.log"),
        logging.StreamHandler()
    ]
)

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'your-secret-key-here')
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size
app.config['JOB_RETENTION_HOURS'] = int(os.environ.get('JOB_RETENTION_HOURS', 24))

# Global dictionary to store job status
jobs = {}
jobs_lock = threading.Lock()

def save_json(data, filename):
    """Save data to JSON file with error handling"""
    try:
        os.makedirs(os.path.dirname(filename), exist_ok=True)
        with open(filename, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return True
    except Exception as e:
        logging.error(f"Error saving JSON to {filename}: {str(e)}")
        return False

def update_job_status(job_id, status, progress=0, current_step="", error=""):
    """Update job status in a thread-safe manner"""
    with jobs_lock:
        if job_id in jobs:
            if status:
                jobs[job_id]["status"] = status
            if progress:
                jobs[job_id]["progress"] = progress
            if current_step:
                jobs[job_id]["current_step"] = current_step
            if error:
                jobs[job_id]["error"] = error
            jobs[job_id]["last_updated"] = datetime.now().isoformat()
            return True
        return False

def process_video_generation(job_id, title, description, voice_id):
    """Background task for video generation with comprehensive error handling"""
    try:
        logging.info(f"Starting video generation for job {job_id}")
        update_job_status(job_id, "processing", 10, "Initializing job")
        
        # Create job-specific directories
        job_dir = f"jobs/{job_id}"
        debug_dir = f"{job_dir}/debug_outputs"
        output_dir = f"{job_dir}/output"
        images_dir = f"{job_dir}/images"
        
        try:
            os.makedirs(job_dir, exist_ok=True)
            os.makedirs(debug_dir, exist_ok=True)
            os.makedirs(output_dir, exist_ok=True)
            os.makedirs(images_dir, exist_ok=True)
        except Exception as e:
            error_msg = f"Directory creation failed: {str(e)}"
            update_job_status(job_id, "error", 0, "Initialization failed", error_msg)
            logging.error(error_msg)
            return
        
        # Step 1: Generate script and mood
        update_job_status(job_id, "processing", 20, "Generating script and mood")
        logging.info(f"[Job {job_id}] Step 1: Generating script and mood")
        
        try:
            script_response = generate_script(title, description)
            if script_response.get("status") != 200:
                error_msg = f"Script generation failed: {script_response.get('error', 'Unknown error')}"
                update_job_status(job_id, "error", 20, "Script generation failed", error_msg)
                logging.error(f"[Job {job_id}] {error_msg}")
                return
            
            script = script_response["script"]
            mood = script_response["mood"]
            if not save_json(script_response, f"{debug_dir}/script_and_mood.json"):
                logging.warning(f"[Job {job_id}] Failed to save script JSON")
        except Exception as e:
            error_msg = f"Script generation exception: {str(e)}"
            update_job_status(job_id, "error", 20, "Script generation failed", error_msg)
            logging.error(f"[Job {job_id}] {error_msg}")
            logging.error(traceback.format_exc())
            return
        
        # Step 2: Generate voiceover
        update_job_status(job_id, "processing", 30, "Generating voiceover")
        logging.info(f"[Job {job_id}] Step 2: Generating voiceover")
        
        try:
            api_keys = [
                "sk_11a82b7ac08e317fe587fd98f75f5f1b438736e42cc7d416",
                "sk_bc92458b535ab85b781e912dd7fa07043a4ac263d16edcf0",
                "sk_c342f396d2f7f802f78b26f87ec1df173689169624c02f66"
            ]
            audio_status, audio_message = generate_audio_with_failover(
                script, voice_id, api_keys, output_path=f"{output_dir}/output.mp3"
            )
            if audio_status == "error":
                error_msg = f"Voiceover generation failed: {audio_message}"
                update_job_status(job_id, "error", 30, "Voiceover generation failed", error_msg)
                logging.error(f"[Job {job_id}] {error_msg}")
                return
        except Exception as e:
            error_msg = f"Voiceover generation exception: {str(e)}"
            update_job_status(job_id, "error", 30, "Voiceover generation failed", error_msg)
            logging.error(f"[Job {job_id}] {error_msg}")
            logging.error(traceback.format_exc())
            return
        
        # Step 3: Transcribe audio
        update_job_status(job_id, "processing", 45, "Transcribing audio")
        logging.info(f"[Job {job_id}] Step 3: Transcribing voiceover")
        
        try:
            transcription_segments = transcribe_audio_with_timestamps(f"{output_dir}/output.mp3")
            if not transcription_segments or "error" in transcription_segments[0]:
                error_msg = f"Transcription failed: {transcription_segments[0].get('error', 'Unknown error')}"
                update_job_status(job_id, "error", 45, "Transcription failed", error_msg)
                logging.error(f"[Job {job_id}] {error_msg}")
                return
            if not save_json(transcription_segments, f"{debug_dir}/transcription.json"):
                logging.warning(f"[Job {job_id}] Failed to save transcription JSON")
        except Exception as e:
            error_msg = f"Transcription exception: {str(e)}"
            update_job_status(job_id, "error", 45, "Transcription failed", error_msg)
            logging.error(f"[Job {job_id}] {error_msg}")
            logging.error(traceback.format_exc())
            return
        
        # Step 4: Generate image prompts
        update_job_status(job_id, "processing", 60, "Generating image prompts")
        logging.info(f"[Job {job_id}] Step 4: Generating image prompts")
        
        try:
            images_prompt = generate_image_prompts(script)
            if not images_prompt:
                error_msg = "Image prompt generation failed"
                update_job_status(job_id, "error", 60, "Image prompt generation failed", error_msg)
                logging.error(f"[Job {job_id}] {error_msg}")
                return
            
            # Handle different prompt response formats
            if isinstance(images_prompt, dict):
                possible_keys = ['images', 'prompts', 'data', 'items', 'list']
                images_prompts = None
                for key in possible_keys:
                    if key in images_prompt:
                        images_prompts = images_prompt[key]
                        break
                if images_prompts is None:
                    error_msg = f"Could not extract image prompts. Available keys: {list(images_prompt.keys())}"
                    update_job_status(job_id, "error", 60, "Image prompt extraction failed", error_msg)
                    logging.error(f"[Job {job_id}] {error_msg}")
                    return
            else:
                images_prompts = images_prompt
            
            if not save_json(images_prompts, f"{debug_dir}/image_prompts.json"):
                logging.warning(f"[Job {job_id}] Failed to save image prompts JSON")
        except Exception as e:
            error_msg = f"Image prompt generation exception: {str(e)}"
            update_job_status(job_id, "error", 60, "Image prompt generation failed", error_msg)
            logging.error(f"[Job {job_id}] {error_msg}")
            logging.error(traceback.format_exc())
            return
        
        # Step 5: Generate images
        update_job_status(job_id, "processing", 70, "Generating images")
        logging.info(f"[Job {job_id}] Step 5: Generating images")
        
        try:
            api_key = "4ea423e8902263c3255e84c2dc4c4bfd69efe385133cb60e923263422bc1ddcd"
            together_generator = TogetherImageGenerator(api_key=api_key, delay=5,output_dir=images_dir)
            together_generator.generate_images_from_prompts(images_prompts)
        except Exception as e:
            error_msg = f"Image generation exception: {str(e)}"
            update_job_status(job_id, "error", 70, "Image generation failed", error_msg)
            logging.error(f"[Job {job_id}] {error_msg}")
            logging.error(traceback.format_exc())
            return
        
        # Step 6: Analyze image placements
        update_job_status(job_id, "processing", 85, "Analyzing image placements")
        logging.info(f"[Job {job_id}] Step 6: Determining image placements")
        
        try:
            image_timestamps = get_image_placements(script, transcription_segments, images_prompts)
            if not image_timestamps:
                error_msg = "Image-timestamp alignment failed"
                update_job_status(job_id, "error", 85, "Image placement failed", error_msg)
                logging.error(f"[Job {job_id}] {error_msg}")
                return
            if not save_json(image_timestamps, f"{debug_dir}/image_placements.json"):
                logging.warning(f"[Job {job_id}] Failed to save image placements JSON")
        except Exception as e:
            error_msg = f"Image placement exception: {str(e)}"
            update_job_status(job_id, "error", 85, "Image placement failed", error_msg)
            logging.error(f"[Job {job_id}] {error_msg}")
            logging.error(traceback.format_exc())
            return
        
        # Step 7: Create final video
        update_job_status(job_id, "processing", 95, "Creating final video")
        logging.info(f"[Job {job_id}] Step 7: Creating final video")
        
        try:
            create_slide_video(
            image_folder=f"{job_dir}/images",
            timestamp_json_path=f"{job_dir}/debug_outputs/image_placements.json",
            audio_path=f"{job_dir}/output/output.mp3",
            output_path=f"{job_dir}/final_video_9x16.mp4"
        )
            
            # Verify video was created
            if not os.path.exists(f"{output_dir}/final_video_9x16.mp4"):
                error_msg = "Video file not created"
                update_job_status(job_id, "error", 95, "Video creation failed", error_msg)
                logging.error(f"[Job {job_id}] {error_msg}")
                return
        except Exception as e:
            error_msg = f"Video creation exception: {str(e)}"
            update_job_status(job_id, "error", 95, "Video creation failed", error_msg)
            logging.error(f"[Job {job_id}] {error_msg}")
            logging.error(traceback.format_exc())
            return
        
        # Final success
        update_job_status(job_id, "completed", 100, "Video generation complete")
        jobs[job_id]["video_path"] = f"{output_dir}/final_video_9x16.mp4"
        jobs[job_id]["completed_at"] = datetime.now().isoformat()
        logging.info(f"[Job {job_id}] Video generation completed successfully")
        
    except Exception as e:
        error_msg = f"Unhandled exception in job processing: {str(e)}"
        update_job_status(job_id, "error", 0, "Critical error", error_msg)
        logging.error(f"[Job {job_id}] {error_msg}")
        logging.error(traceback.format_exc())

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/generate', methods=['POST'])
def generate_video():
    try:
        # Handle both form data and JSON requests
        if request.is_json:
            data = request.get_json()
            title = data.get('title', '').strip()
            description = data.get('description', '').strip()
            voice_id = data.get('voice_id', 'm5qndnI7u4OAdXhH0Mr5').strip()
        else:
            title = request.form.get('title', '').strip()
            description = request.form.get('description', '').strip()
            voice_id = request.form.get('voice_id', 'm5qndnI7u4OAdXhH0Mr5').strip()

        # Validate required fields
        if not title or not description:
            return jsonify({"error": "Title and description are required"}), 400
        
        # Generate unique job ID
        job_id = str(uuid.uuid4())
        
        # Initialize job status with thread-safe locking
        with jobs_lock:
            jobs[job_id] = {
                "status": "queued",
                "title": title,
                "description": description,
                "voice_id": voice_id,
                "created_at": datetime.now().isoformat(),
                "last_updated": datetime.now().isoformat(),
                "progress": 0,
                "current_step": "Queued"
            }
        
        # Start background processing
        thread = threading.Thread(
            target=process_video_generation,
            args=(job_id, title, description, voice_id)
        )
        thread.daemon = True
        thread.start()
        
        return jsonify({
            "job_id": job_id, 
            "status": "queued",
            "message": "Video generation started successfully"
        })
        
    except Exception as e:
        logging.error(f"Error in generate_video endpoint: {str(e)}")
        logging.error(traceback.format_exc())
        return jsonify({"error": "Internal server error"}), 500

@app.route('/status/<job_id>')
def get_job_status(job_id):
    try:
        with jobs_lock:
            if job_id not in jobs:
                return jsonify({"error": "Job not found"}), 404
            
            # Create a safe copy to return
            job_data = jobs[job_id].copy()
            
            # Remove large data if present
            job_data.pop("script", None)
            job_data.pop("transcription", None)
            job_data.pop("image_prompts", None)
            
            return jsonify(job_data)
            
    except Exception as e:
        logging.error(f"Error retrieving status for job {job_id}: {str(e)}")
        return jsonify({"error": "Internal server error"}), 500

@app.route('/download/<job_id>')
def download_video(job_id):
    try:
        with jobs_lock:
            if job_id not in jobs:
                return jsonify({"error": "Job not found"}), 404

        job = jobs[job_id]
        if job["status"] != "completed":
            return jsonify({"error": "Video not ready"}), 400
        
        video_path = job.get("video_path")
        if not video_path or not os.path.exists(video_path):
            return jsonify({"error": "Video file not found"}), 404
        
        return send_file(
            video_path,
            as_attachment=True,
            download_name=f"video_{job_id}.mp4",
            mimetype='video/mp4'
        )
        
    except Exception as e:
        logging.error(f"Error downloading video for job {job_id}: {str(e)}")
        return jsonify({"error": "Internal server error"}), 500

@app.route('/jobs')
def list_jobs():
    try:
        # Create a safe list of jobs without sensitive data
        safe_jobs = {}
        for job_id, job_data in jobs.items():
            safe_job = {
                "job_id": job_id,
                "status": job_data.get("status", "unknown"),
                "title": job_data.get("title", ""),
                "progress": job_data.get("progress", 0),
                "created_at": job_data.get("created_at", ""),
                "current_step": job_data.get("current_step", "")
            }
            safe_jobs[job_id] = safe_job
            
        return render_template('jobs.html', jobs=safe_jobs)
        
    except Exception as e:
        logging.error(f"Error listing jobs: {str(e)}")
        return jsonify({"error": "Internal server error"}), 500

@app.route('/job/<job_id>')
def view_job(job_id):
    try:
        with jobs_lock:
            if job_id not in jobs:
                return redirect(url_for('index'))
                
            # Create a safe copy to display
            job_data = jobs[job_id].copy()
            
            # Remove large data if present
            job_data.pop("script", None)
            job_data.pop("transcription", None)
            job_data.pop("image_prompts", None)
            
            return render_template('job_detail.html', job=job_data, job_id=job_id)
            
    except Exception as e:
        logging.error(f"Error viewing job {job_id}: {str(e)}")
        return redirect(url_for('index'))

def cleanup_old_jobs():
    """Remove jobs older than retention period"""
    try:
        current_time = datetime.now()
        retention_hours = app.config['JOB_RETENTION_HOURS']
        jobs_to_remove = []
        
        with jobs_lock:
            for job_id, job_data in jobs.items():
                created_at = datetime.fromisoformat(job_data["created_at"])
                if (current_time - created_at) > timedelta(hours=retention_hours):
                    jobs_to_remove.append(job_id)
            
            for job_id in jobs_to_remove:
                # Clean up files
                job_dir = f"jobs/{job_id}"
                if os.path.exists(job_dir):
                    try:
                        shutil.rmtree(job_dir)
                        logging.info(f"Cleaned up job directory: {job_dir}")
                    except Exception as e:
                        logging.error(f"Error cleaning job directory {job_dir}: {str(e)}")
                
                # Remove from jobs dict
                del jobs[job_id]
                logging.info(f"Removed old job: {job_id}")
                
    except Exception as e:
        logging.error(f"Error in cleanup_old_jobs: {str(e)}")
        logging.error(traceback.format_exc())

if __name__ == '__main__':
    # Create necessary directories
    os.makedirs('jobs', exist_ok=True)
    os.makedirs('uploads', exist_ok=True)
    
    # Run cleanup every hour in a daemon thread
    def cleanup_scheduler():
        while True:
            try:
                cleanup_old_jobs()
            except Exception as e:
                logging.error(f"Error in cleanup scheduler: {str(e)}")
            time.sleep(3600)  # Run every hour
    
    cleanup_thread = threading.Thread(target=cleanup_scheduler)
    cleanup_thread.daemon = True
    cleanup_thread.start()
    
    # Start the Flask app
    app.run(debug=True, host='0.0.0.0', port=5000, threaded=True)
