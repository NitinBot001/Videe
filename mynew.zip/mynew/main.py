from image_generation import TogetherImageGenerator
from trasnscript import transcribe_audio_with_timestamps
from script_mood import generate_script  # ✅ Your function for script + mood
from voiceover import generate_audio_with_failover
from video_generation import create_slide_video
from timestamp_analize import get_image_placements
from image_prompt import extract_image_prompts_from_script as generate_image_prompts

import json
import os


def save_json(data, filename):
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def main():
    try:
        print("\n[🔁 STEP 1] Generating script and mood from title/description...")
        title = "ज़हर खा रहे हो या खाना? असली फर्क जानिए!"
#        description = "खेती में पानी की कमी से कैसे निपटा जा सकता है? आसान और सस्ते तरीके जो हर किसान अपना सकता है।"
        description = """ सब्ज़ियाँ हरी दिखती हैं, पर क्या वो ज़हरीली हैं? जानिए जैविक खेती क्या होती है, इसके फायदे और क्यों हर किसान को इस ओर बढ़ना चाहिए। एक छोटी सी जानकारी आपके खाने की थाली को बदल सकती है!"""
        voice_id = "m5qndnI7u4OAdXhH0Mr5"  # ✅ Replace this with your actual ElevenLabs voice ID

        script_response = generate_script(title, description)
        if script_response.get("status") != 200:
            print("[❌ ERROR] Script generation failed:", script_response.get("error"))
            return

        script = script_response["script"]
        mood = script_response["mood"]
        print("[✅ SUCCESS] Script and mood generated.")
        save_json(script_response, "debug_outputs/script_and_mood.json")

        print("\n[🔁 STEP 2] Generating voiceover from script...")
        api_keys = [
            "sk_11a82b7ac08e317fe587fd98f75f5f1b438736e42cc7d416",
            "sk_bc92458b535ab85b781e912dd7fa07043a4ac263d16edcf0",
            "sk_c342f396d2f7f802f78b26f87ec1df173689169624c02f66"
        ]
        audio_status, audio_message = generate_audio_with_failover(script, voice_id, api_keys)
        if audio_status == "error":
            print("[❌ ERROR] Voiceover generation failed:", audio_message)
            return
        print("[✅ SUCCESS] Voiceover saved as output/output.mp3")

        print("\n[🔁 STEP 3] Transcribing voiceover with Whisper...")
        transcription_segments = transcribe_audio_with_timestamps("output/output.mp3")
        if not transcription_segments or "error" in transcription_segments[0]:
            print("[❌ ERROR] Transcription failed:", transcription_segments[0].get("error"))
            return
        print("[✅ SUCCESS] Transcription completed.")
        save_json(transcription_segments, "debug_outputs/transcription.json")

        print("\n[🔁 STEP 4] Generating image prompts from script...")
        images_prompt = generate_image_prompts(script)
        if not images_prompt:
            print("[❌ ERROR] Image prompt generation failed.")
            return
        print("[✅ SUCCESS] Image prompts generated.")
        save_json(images_prompt, "debug_outputs/image_prompts.json")

        print("\n[🔁 STEP 5] Generating images with TogetherAI...")
        print(f"🔍 Type of images_prompt: {type(images_prompt)}")
        print(f"🔍 Keys in images_prompt: {list(images_prompt.keys()) if isinstance(images_prompt, dict) else 'Not a dict'}")
        print(f"🔍 First few items: {str(images_prompt)[:200]}...")
        
        # Try to extract the list
        if isinstance(images_prompt, dict):
            # Common key names to try
            possible_keys = ['images', 'prompts', 'data', 'items', 'list']
            images_prompts = None
            
            for key in possible_keys:
                if key in images_prompt:
                    images_prompts = images_prompt[key]
                    print(f"✅ Found data under key: '{key}'")
                    break
            
            if images_prompts is None:
                # If none of the common keys work, show all keys
                print(f"🔍 Available keys: {list(images_prompt.keys())}")
                # You might need to manually specify the correct key here
                return
        else:
            images_prompts = images_prompt
        
        api_key = "4ea423e8902263c3255e84c2dc4c4bfd69efe385133cb60e923263422bc1ddcd"
        together_generator = TogetherImageGenerator(api_key=api_key, delay=5)
        together_generator.generate_images_from_prompts(images_prompts)
        print("[✅ SUCCESS] All images saved in /images")
        print("\n[🔁 STEP 6] Determining image placements using Gemini...")
        image_timestamps = get_image_placements(
            script,
            transcription_segments,
            images_prompt
        )
        if not image_timestamps:
            print("[❌ ERROR] Image-timestamp alignment failed.")
            return
        save_json(image_timestamps, "debug_outputs/image_placements.json")
        print("[✅ SUCCESS] Image placement analysis done.")

        print("\n[🔁 STEP 7] Creating final video with FFmpeg...")
        create_slide_video(
            image_folder="images",
            timestamp_json_path="debug_outputs/image_placements.json",
            audio_path="output/output.mp3",
            output_path="final_video_9x16.mp4"
        )
        print("[🎉 FINAL OUTPUT] Video saved as final_video_9x16.mp4")

    except Exception as e:
        print(f"[❌ FATAL ERROR] Unhandled exception:\n{e}")


if __name__ == "__main__":
    main()
