import os
import json
from google import genai
from google.genai import types

def extract_image_prompts_from_script(script_text):
    try:
        # Get API key from environment
        api_key = os.getenv("GEMINI_API_KEY", "AIzaSyBQBfbhPqtL2SEKh3l_0cE6zIxwMKLTi-A")
        client = genai.Client(api_key=api_key)

        system_instruction = """You are a professional visual content analyst and image prompt generator.

You are given a Hindi video voiceover script meant for educational YouTube Shorts (~120 seconds long). Your task is to read the entire script and analyze it to generate a structured list of image descriptions and prompts.

Follow these rules strictly:

1. Read the full script carefully.
2. Divide the script into meaningful visual scenes. Try to extract as many distinct visuals as possible.
3. For each scene:
   - Write a short, clear `description` in English about the visual content.
   - Write a `prompt` suitable for text-to-image generation using models like Stable Diffusion, DALL·E, or Midjourney.
   - Make the prompt detailed and creative but not too long (1–2 lines max).
   - Add an `id` key starting from 1 and incrementing.

4. Your final output must be a pure JSON array of objects. Each object should have:
   - `id` (integer)
   - `description` (English)
   - `prompt` (English)

5. Do not include any other explanation or introduction — just output clean JSON.

6. (Follow this very strictly) We are supposing to in video have about 120 - 150 words per minute. So i want a image for maximum 5 second to usin the video so if there have 100 words in script so generate prompt for 20 images minimum.
"""

        contents = [
            types.Content(
                role="user", 
                parts=[
                    types.Part.from_text(text=script_text)
                ]
            )
        ]

        config = types.GenerateContentConfig(
            system_instruction=[
                types.Part.from_text(text=system_instruction)
            ],
            response_mime_type="application/json"
        )

        response = client.models.generate_content(
            model="gemini-2.0-flash-exp",
            contents=contents,
            config=config
        )

        # Parse JSON response
        try:
            json_data = json.loads(response.text.strip())
        except json.JSONDecodeError as e:
            return {
                "status": 500,
                "error": f"Invalid JSON response: {str(e)}"
            }

        # Save output to JSON file
        try:
            with open("image_prompts.json", "w", encoding="utf-8") as f:
                json.dump(json_data, f, indent=2, ensure_ascii=False)
            print("Saved to image_prompts.json ✅")
        except Exception as e:
            print(f"Warning: Could not save to file: {str(e)}")

        return {
            "status": 200,
            "data": json_data,
            "count": len(json_data) if isinstance(json_data, list) else 0
        }

    except Exception as e:
        return {
            "status": 500,
            "error": f"Failed to extract image prompts: {str(e)}"
        }

def test_extraction():
    """Test function with sample script"""
    hindi_script = """
क्या आपने कभी सोचा है कि जिस थाली में हम खाना खाते हैं, वह हमारे स्वास्थ्य को कैसे प्रभावित करती है? आज हम जानेंगे स्टील की थाली के फायदे। पहला फायदा, स्टील में कोई हानिकारक रसायन नहीं होते। प्लास्टिक के बर्तनों से निकलने वाले टॉक्सिन्स हमारे शरीर में जाकर बीमारियां फैलाते हैं। दूसरा, स्टील की थाली टिकाऊ होती है। एक बार खरीदने पर सालों साल चलती है। तीसरा, यह पर्यावरण के लिए सुरक्षित है। तो आज से ही स्टील की थाली का इस्तेमाल करें और स्वस्थ रहें।
"""
    
    result = extract_image_prompts_from_script(hindi_script)
    print("Result:", json.dumps(result, indent=2, ensure_ascii=False))
    return result

if __name__ == "__main__":
    test_extraction()
